#ifndef MATCHING_H
#define MATCHING_H

#include "animal.h"
#include "client.h"
#include "unitOfMatching.h"
#include "list.h"
#include <cmath>
using namespace std;

class Matching
{
public:
    Matching();

    // Pair store the id of the matching object with its matching value
    class Pair{
        friend class AnimalForMatching;
        friend class ClientForMatching;
        friend class Matching;
    protected:
        int id;
        string name;
        float matchingValue;
    };


    // AnimalForMatching store the id of one animal and all the suitable matching client
    // with the form of Pair
    class AnimalForMatching{
        friend class Matching;
    protected:
        int aid;
        string aName;
        std::vector<Pair> matchingClients;
    };

    // ClientForMatching store the id of one client and all the suitable matching animal
    // with the form of Pair
    class ClientForMatching {
        friend class Matching;
    protected:
        int cid;
        string cName;
        std::vector<Pair> matchingAnimals;

    };
    std::vector<UnitOfMatching> run();
    void initialize(List<Animal>&, List<Client>&);

protected:
    vector<vector<float> > Matrix;
    std::vector<UnitOfMatching> matchResult;
    float compute(Animal*,Client*);
    List<Animal> al;
    List<Client> cl;


};

#endif // MATCHING_H
