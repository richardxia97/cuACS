#ifndef CONTACTINFO_H
#define CONTACTINFO_H
#include <iostream>

using namespace std;
class ContactInfo
{
public:
    ContactInfo();
    string getPhone();
    void setPhone(string);
    string getEmail();
    void setEmail(string);
    string getAddress();
    void setAddress(string);
    string getPostCode();
    void setPostCode(string);

private:
    string phone;
    string email;
    string address;
    string postCode;
};

#endif // CONNECTINFO_H
