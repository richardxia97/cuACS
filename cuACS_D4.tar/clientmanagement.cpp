#include "clientmanagement.h"

ClientManagement::ClientManagement()
{

}


int ClientManagement::loadClientData(string fileName){
    clientList.clear();
    QString data;
    QFile myfile(QString::fromStdString(fileName));
    myfile.open(QIODevice::ReadOnly);
    QTextStream txtInput(&myfile);
    Client* client;
    while(!txtInput.atEnd()){
        client = new Client();
        data = txtInput.readLine();
        client->setClientID(data.toInt());
        data = txtInput.readLine();
        client->setClientName(data.toStdString());
        data = txtInput.readLine();
        client->setClientPassword(data.toStdString());
        data = txtInput.readLine();
        client->ci.setPhone(data.toStdString());
        data = txtInput.readLine();
        client->ci.setEmail(data.toStdString());
        data = txtInput.readLine();
        client->ci.setAddress(data.toStdString());
        data = txtInput.readLine();
        client->ci.setPostCode(data.toStdString());
        data = txtInput.readLine();
        client->mi.setHasChild(data.toInt());
        data = txtInput.readLine();
        client->mi.setHasElder(data.toInt());
        data = txtInput.readLine();
        client->mi.setFamilyMemeber(data.toInt());
        data = txtInput.readLine();
        client->mi.setFirstName(data.toStdString());
        data = txtInput.readLine();
        client->mi.setFamilyName(data.toStdString());
        data = txtInput.readLine();
        client->mi.setAge(data.toInt());
        data = txtInput.readLine();
        client->mi.setRoutine(data.toInt());
        data = txtInput.readLine();
        client->mi.setExperienced(data.toInt());
        data = txtInput.readLine();
        client->mi.setAvailableTime(data.toInt());
        data = txtInput.readLine();
        client->mi.setIncome(data.toInt());
        int p[5];
        for(int i = 0; i< 5;i++){
            data = txtInput.readLine();
            p[i] = data.toInt();
        }
        client->mi.setPersonality(p);
        data = txtInput.readLine();
        client->mi.setRequirement(data.toInt());
        data = txtInput.readLine();
        client->mi.setWillingness(data.toInt());
        clientList.add(client);
    }
    myfile.close();
    return 0;
}

int ClientManagement::saveClientData(string fileName){
    QFile myfile(QString::fromStdString((fileName)));
    myfile.open(QIODevice::WriteOnly);
    QTextStream txtOutput(&myfile);
    node<Client>* temp=clientList.getHeadNode();
    Client* client;
    while (temp != NULL){
        client = temp->obj;
        txtOutput<<client->getClientID()<<"\n";
        txtOutput<<QString::fromStdString(client->getClientName())<<"\n";
        txtOutput<<QString::fromStdString(client->getClientPassword())<<"\n";
        txtOutput<<QString::fromStdString(client->ci.getPhone())<<"\n";
        txtOutput<<QString::fromStdString(client->ci.getEmail())<<"\n";
        txtOutput<<QString::fromStdString(client->ci.getAddress())<<"\n";
        txtOutput<<QString::fromStdString(client->ci.getPostCode())<<"\n";
        txtOutput<<client->mi.getHasChild()<<"\n";
        txtOutput<<client->mi.getHasElder()<<"\n";
        txtOutput<<client->mi.getFamilyMemeber()<<"\n";
        txtOutput<<QString::fromStdString(client->mi.getFirstName())<<"\n";
        txtOutput<<QString::fromStdString(client->mi.getFamilyName())<<"\n";
        txtOutput<<client->mi.getAge()<<"\n";
        txtOutput<<client->mi.getRoutine()<<"\n";
        txtOutput<<client->mi.getExperienced()<<"\n";
        txtOutput<<client->mi.getAvailableTime()<<"\n";
        txtOutput<<client->mi.getIncome()<<"\n";
        for(int i =0;i<5;i++){
                    txtOutput<<client->mi.getPersonality()[i]<<"\n";
        }
        txtOutput<<client->mi.getRequirement()<<"\n";
        txtOutput<<client->mi.getWillingness()<<"\n";
        temp = temp->next;
    }
    myfile.close();
    return 0;
}


int ClientManagement::verify(string name, string pw){
    node<Client>* temp = clientList.getHeadNode();
    Client* client;
    while (temp != NULL) {
        client = temp->obj;
        if(client->getClientName() == name && client->getClientPassword() == pw){
            return client->getClientID();
        }
        temp = temp->next;
    }
    return -1;
}
