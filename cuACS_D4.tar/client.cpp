#include "client.h"

Client::Client()
{

}

void Client::setClientID(int id){clientID = id; }
void Client::setClientName(string name){clientName = name; }
void Client::setClientPassword(string pw){password = pw; }
int Client::getClientID(){return clientID;}
string Client::getClientName(){return clientName;}
string Client::getClientPassword(){return password;}

string Client::briefDescription(){
    return ci.getPhone()+", "+ci.getEmail();
}
