//PhysicalAttributes.h
#ifndef PHYSICALATTRIBUTES_H
#define PHYSICALATTRIBUTES_H


#include <iostream>

using namespace std;

class PhysicalAttributes
{
private:
  string species;
  int ageStage;
  bool gender;
  int classification;
public:
  string getSpecies();
  int getSize();
  int getAgeStage();
  bool getGender();
  int getClassification();
  void setSpecies(string);
  void setSize(int);
  void setAgeStage(int);
  void setGender(bool);
  void setClassification(int);
  PhysicalAttributes();
};

#endif
