#include "matchinginfo.h"

MatchingInfo::MatchingInfo()
{

}
