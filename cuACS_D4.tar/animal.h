//Animal.h
#ifndef ANIMAL_H
#define ANIMAL_H

#include "nonphysicalattributes.h"
#include "physicalattributes.h"
#include <iostream>
#include <QString>
#include <QTextStream>

class Animal
{
public:
  string briefDescription();
  void setAnimalName(string animalName);
  int getAnimalID();
  void setAnimalID(int);
  string getAnimalName();
  void loadData(QTextStream);
  void writeData(QTextStream);
  Animal();
  ~Animal();

  PhysicalAttributes pa;
  NonPhysicalAttributes npa;
private:
  int AID;
  string animalName;
};

#endif
