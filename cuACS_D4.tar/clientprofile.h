#ifndef CLIENTPROFILE_H
#define CLIENTPROFILE_H

#include <QDialog>
#include "client.h"
#include <QMessageBox>

namespace Ui {
class ClientProfile;
}

class ClientProfile : public QDialog
{
    Q_OBJECT

public:
    explicit ClientProfile(QWidget *parent = 0);
    ~ClientProfile();
    void initialize(Client*);
    void readOnly(bool);

signals:
    void update();

private slots:

    void on_tip_clicked();

    void on_ok_clicked();

    void on_tip_2_clicked();

    void on_tip_3_clicked();

private:
    Ui::ClientProfile *ui;
    Client* client;
};

#endif // CLIENTPROFILE_H
