#include "clientview.h"
#include "ui_clientview.h"
#include "animalprofile.h"

ClientView::ClientView(QWidget *parent) :
    View(parent)

{
    ui = new Ui::ClientView();
    ui->setupUi(this);

    // set window

    this->setWindowIcon(QIcon(":/resource/logo.ico"));




    //set animal table
    QStringList header;
    header<<"ID"<<"name"<<"Description";
    ui->animalList->setHorizontalHeaderLabels(header);
    ui->animalList->horizontalHeader()->setStretchLastSection(true);

    ui->animalList->setColumnWidth(0, 40);
    ui->animalList->setColumnWidth(1, 100);


    ui->animalList->setSelectionBehavior ( QAbstractItemView::SelectRows);
    ui->animalList->setSelectionMode ( QAbstractItemView::SingleSelection);


}

ClientView::~ClientView()
{
    delete ui;
}



int ClientView::getSelectedAnimalIndex(){
    bool focus = ui->animalList->isItemSelected(ui->animalList->currentItem());
    int row = ui->animalList->currentRow();
    return focus? row:-1;
}

void ClientView::updateAnimalList(List<Animal>& al){
    node<Animal>* temp = al.getHeadNode();
    QTableWidgetItem* content;
    int row;
    ui->animalList->clear();
    ui->animalList->setRowCount(0);
    QStringList header;
    header<<"ID"<<"name"<<"Description";
    ui->animalList->setHorizontalHeaderLabels(header);
    ui->animalList->horizontalHeader()->setStretchLastSection(true);
    while(temp!=NULL){
        Animal* animal = temp->obj;
        row = ui->animalList->rowCount();
        ui->animalList->setRowCount(row+1);
        ui->animalList->setRowHeight(row,20);
        content = new QTableWidgetItem(QString::fromStdString(to_string(animal->getAnimalID())));
        ui->animalList->setItem(row,0,content);
        content = new QTableWidgetItem(QString::fromStdString(animal->getAnimalName()));
        ui->animalList->setItem(row,1,content);
        content = new QTableWidgetItem(QString::fromStdString(animal->briefDescription()));
        ui->animalList->setItem(row,2,content);
        temp = temp->next;
    }
}



void ClientView::on_viewAnimalDetails_clicked()
{
    emit viewAnimalDetails();
}

void ClientView::on_editprofile_clicked()
{
    emit editClientProfile();
}

void ClientView::on_logOut_clicked()
{
    emit logOut();
}
