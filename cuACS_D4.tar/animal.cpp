//animal.cpp

#include "animal.h"

#define CUB 0
#define MATURE 1
#define ELDER 2


#define PREVIOUSOWNER 0
#define HOMELESS 1
#define LABORATORY 2
#define RESCUE 3


Animal::Animal(){
    AID = 0;
    animalName = "";
}

Animal::~Animal(){}

string Animal::briefDescription(){
    string str = "";
    str += pa.getGender()? "male":"femina";
    string ageStage;
    switch(pa.getAgeStage()){
    case CUB:
        ageStage = " cub ";
        break;
    case MATURE:
        ageStage = " mature ";
        break;
    case ELDER:
        ageStage = " elder ";
        break;
    }
    str += ageStage;
    str += pa.getSpecies()==""? "unknown species":pa.getSpecies();
    str += ", from ";
    switch(npa.getResource()){
    case LABORATORY:
        str += "laboratory";
        break;
    case PREVIOUSOWNER:
        str += "previous owner";
        break;
    case HOMELESS:
        str += "homeless";
        break;
    case RESCUE:
        str += "rescue";
        break;
    };


    return str;
  }
void Animal::setAnimalName(string aName){
  animalName = aName;
}
int Animal::getAnimalID(){
  return AID;
}
void Animal::setAnimalID(int aid){
  AID = aid;
}
string Animal::getAnimalName(){
  return animalName;
}
