#ifndef STAFFVIEW_H
#define STAFFVIEW_H

#include <QMainWindow>
#include <QSignalMapper>
#include "animal.h"
#include "list.h"
#include "view.h"
#include "unitOfMatching.h"

using namespace std;



namespace Ui {
class StaffView;
}

class StaffView : public  View
{
    Q_OBJECT

public:
    explicit StaffView(QWidget *parent = 0);
    ~StaffView();
    int getUserOperation();
    int getSelectedAnimalIndex();
    void updateAnimalList(List<Animal>&);
    void updateClientList(List<Client>&);
    int getSelectedClientIndex();
    void updateMatchResult(std::vector<UnitOfMatching>);
    int getSelectedMatchPairIndex();
private:
    Ui::StaffView *ui;


private slots:
    void on_logOut_clicked();
    
    void on_addAnimal_clicked();
    
    void on_editAnimal_clicked();
    
    void on_viewAnimalDetails_clicked();
    
    void on_logOut_2_clicked();
    void on_addClient_clicked();
    void on_viewClientDetails_clicked();
    void on_logOut_3_clicked();
    void on_match_clicked();
    void on_viewMatchDetails_clicked();
};

#endif // STAFFVIEW_H
