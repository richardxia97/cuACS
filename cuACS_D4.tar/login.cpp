#include "login.h"
#include "ui_login.h"

LogIn::LogIn(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LogIn)
{
    ui->setupUi(this);
    ui->password->setEchoMode(QLineEdit::Password);
}

LogIn::~LogIn()
{
    delete ui;
}

void LogIn::on_exit_clicked()
{
    emit exitSystem();
}

void LogIn::on_logIn_clicked()
{
    emit login(ui->userName->text().toStdString(),ui->password->text().toStdString());
}
