#ifndef CLIENTMANAGEMENT_H
#define CLIENTMANAGEMENT_H

#include "list.h"
#include "client.h"
#include <fstream>
#include <iostream>
#include <QFile>
#include <QTextStream>

class ClientManagement
{
public:
    ClientManagement();
public:
  int loadClientData(string fileName);
  int saveClientData(string fileName);
  int verify(string,string);

  List<Client> clientList;
};

#endif // CLIENTMANAGEMENT_H
