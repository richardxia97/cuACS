#include "addclient.h"
#include "ui_addclient.h"


AddClient::AddClient(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddClient)
{
    ui->setupUi(this);
    client = new Client();

}

AddClient::~AddClient()
{
    delete ui;
    delete client;
}

void AddClient::on_cancel_clicked()
{
    this->close();
}

void AddClient::on_submit_clicked()
{
    bool checked = true;
    QRegExp emailStyle(tr("^.+@{1}(.+.{1})?.+$"));
    QRegExp phoneStyle(tr("^[0-9]{7,13}$"));
    QString email = ui->email->text();
    QString phone = ui->phone->text();
    int pos = 0;
    QRegExpValidator v1(phoneStyle, 0);
    QRegExpValidator v2(emailStyle, 0);
    if(ui->userName->text() == ""){
        QMessageBox::critical(NULL, "warning", "Please type in user name!", QMessageBox::Yes, QMessageBox::Yes);
        checked = false;
    }else if(ui->password->text() == ""){
        QMessageBox::critical(NULL, "warning", "Please type in password!", QMessageBox::Yes, QMessageBox::Yes);
        checked = false;
    }else if(phone != "" && v1.validate(phone,pos) != QValidator::Acceptable){
        QMessageBox::critical(NULL, "warning", "Please type in a correct phone number!", QMessageBox::Yes, QMessageBox::Yes);
        checked = false;
    }else if(email != "" && v2.validate(email,pos) != QValidator::Acceptable){
        QMessageBox::critical(NULL, "warning", "Please type in email with correct format!", QMessageBox::Yes, QMessageBox::Yes);
        checked = false;
    }
    if(checked){
        client->setClientID(ui->userID->text().toInt());
        client->setClientName(ui->userName->text().toStdString());
        client->setClientPassword(ui->password->text().toStdString());
        client->ci.setPhone(ui->phone->text().toStdString());
        client->ci.setEmail(ui->email->text().toStdString());
        client->ci.setAddress(ui->address->toPlainText().toStdString());
        client->ci.setPostCode(ui->postCode->text().toStdString());
        emit newClient(client);
        this->close();
    }

}


void AddClient::setClientID(int id){
    client->setClientID(id);
    ui->userID->setText(QString::number(id));
}
