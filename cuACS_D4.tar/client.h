#ifndef CLIENT_H
#define CLIENT_H

#include <iostream>
#include "contactinfo.h"
#include "matchinginfo.h"
using namespace std;

class Client
{
public:
    Client();
    void setClientID(int );
    void setClientName(string);
    void setClientPassword(string);
    int getClientID();
    string getClientName();
    string getClientPassword();
    string briefDescription();
    ContactInfo ci;
    MatchingInfo mi;

private:
    int clientID;
    string clientName;
    string password;


};

#endif // CLIENT_H
