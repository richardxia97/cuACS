#include "physicalattributes.h"
PhysicalAttributes::PhysicalAttributes(){
    species = "";
    ageStage = 0;
    gender = true;
    classification = 0;
}

string PhysicalAttributes::getSpecies(){
  return species;
}

int PhysicalAttributes::getAgeStage(){
  return ageStage;
}
bool PhysicalAttributes::getGender(){
  return gender;
}
int PhysicalAttributes::getClassification(){
  return classification;
}
void PhysicalAttributes::setSpecies(string s){
  species = s;
}
void PhysicalAttributes::setAgeStage(int a){
  ageStage = a;
}
void PhysicalAttributes::setGender(bool g){
  gender = g;
}
void PhysicalAttributes::setClassification(int c){
  classification = c;
}
