#include "control.h"

#define ANIMALFILENAME "./resource/Animal.txt"
#define CLIENTFILENAME "./resource/Client.txt"
#define ADMIN -1
#define UNLOGGED -100

Control::~Control(){
    delete view;
}

int Control::launch(int argc, char *argv[]){

    QApplication a(argc, argv);
    am.loadAnimalData(ANIMALFILENAME);
    cm.loadClientData(CLIENTFILENAME);
    if(identity == -1){
        lg = new LogIn();
        lg->show();
        connect(lg,&LogIn::login,this,&Control::requestLogIn);
        connect(lg,&LogIn::exitSystem,this,&Control::exitSystem);
    }
    int re = a.exec();
    delete lg;
    return re;
}


void Control::update(){
    am.saveAnimalData(ANIMALFILENAME);
    cm.saveClientData(CLIENTFILENAME);
    view->updateAnimalList(am.animalList);
    if(identity == -1){
        view->updateClientList(cm.clientList);
    }
}


void Control::receiveNewAnimal(Animal *animal){
    if(animal->getAnimalID()>am.animalList.getLength()){
        am.animalList.add(animal);
    }
    update();
}
void Control::receiveNewClient(Client *client){
    cm.clientList.add(client);
    update();
}

void Control::requestAddAnimal(){
    node<Animal>* n = am.animalList.getTailNode();
    Animal *animal;
    int id = 1;
    if(n != NULL){
        animal = n->obj;
        id = animal->getAnimalID()+1;
    }
    animal = new Animal();
    animal->setAnimalID(id);
    AnimalProfile* ap = new AnimalProfile();
    ap->setWindowModality(Qt::ApplicationModal);
    ap->initialize(animal);
    ap->show();
    connect(ap,&AnimalProfile::newAnimal,this,&Control::receiveNewAnimal);
}

void Control::requestEditAnimal(){
    int index = view->getSelectedAnimalIndex();
    if(index >= 0){
        Animal* animal = am.animalList.get(index);
        AnimalProfile* ap = new AnimalProfile();
        ap->setWindowModality(Qt::ApplicationModal);
        ap->initialize(animal);
        ap->show();
        connect(ap,&AnimalProfile::newAnimal,this,&Control::receiveNewAnimal);
    }else{
        QMessageBox::critical(NULL, "warning", "Please select the animal you want to edit!", QMessageBox::Yes, QMessageBox::Yes);
    }

}

void Control::requestViewAnimalDetails(){
    int index = view->getSelectedAnimalIndex();
    if(index >= 0){
        Animal* animal = am.animalList.get(index);
        AnimalProfile* ap = new AnimalProfile();
        ap->setWindowModality(Qt::ApplicationModal);
        ap->initialize(animal);
        ap->readOnly(true);
        ap->show();
    }else{
        QMessageBox::critical(NULL, "warning", "Please select the animal you want to view!", QMessageBox::Yes, QMessageBox::Yes);
    }
}

void Control::requestViewClientDetails(){
    int index = view->getSelectedClientIndex();
    if(index >= 0){
        Client* client = cm.clientList.get(index);
        ClientProfile* cp = new ClientProfile();
        cp->initialize(client);
        cp->readOnly(true);
        cp->show();
    }else{
        QMessageBox::critical(NULL, "warning", "Please select the client you want to view!", QMessageBox::Yes, QMessageBox::Yes);
    }
}

void Control::requestEditClientProfile(){
    Client* client = cm.clientList.get(identity-1);
    ClientProfile* cp = new ClientProfile();
    cp->initialize(client);
    cp->show();
    connect(cp,&ClientProfile::update,this,&Control::requestUpdate);
}

void Control::requestAddClient(){
    AddClient* ac = new AddClient();
    int id =1;
    node<Client>* n = cm.clientList.getTailNode();
    if(n != NULL){
        Client* client = n->obj;
        id = client->getClientID()+1;
    }
    ac->setClientID(id);
    ac->show();
    connect(ac,&AddClient::newClient,this,&Control::receiveNewClient);
}

void Control::requestLogOut(){
    identity = UNLOGGED;
    view->close();
    this->lg->show();
}
void Control::requestLogIn(string u,string p){
    if (u == "admin" && p == "admin"){
        identity = ADMIN;
        lg->close();

        view = new StaffView();
        view->updateClientList(cm.clientList);


    }else if(cm.verify(u,p)>=0){
        identity = cm.verify(u,p);
        lg->close();
        view = new ClientView();

    }else{
        QMessageBox::critical(NULL, "warning", "Failed to log in. Please try again!", QMessageBox::Yes, QMessageBox::Yes);
        return;
    }
    view->updateAnimalList(am.animalList);
    view->show();
    connect(view,&View::addAnimal,this,&Control::requestAddAnimal);
    connect(view,&View::editAnimal,this,&Control::requestEditAnimal);
    connect(view,&View::viewAnimalDetails,this,&Control::requestViewAnimalDetails);
    connect(view,&View::logOut,this,&Control::requestLogOut);
    connect(view,&View::addClient,this,&Control::requestAddClient);
    connect(view,&View::editClientProfile,this,&Control::requestEditClientProfile);
    connect(view,&View::viewClientDetails,this,&Control::requestViewClientDetails);
    connect(view,&View::matching,this,&Control::requestMatch);
    connect(view,&View::viewMatchingDetial,this,&Control::requestViewMatchDetails);
}

void Control::requestMatch(){
    matchingResult.clear();
    matching.initialize(am.animalList,cm.clientList);
    matchingResult = matching.run();
    view->updateMatchResult(matchingResult);
}

void Control::requestViewMatchDetails(){
    int index = view->getSelectedMatchPairIndex();
    if(index >= 0){
        Client* client = cm.clientList.get(matchingResult[index].cid);
        Animal* animal = am.animalList.get(matchingResult[index].aid);
        ClientProfile* cp = new ClientProfile();
        AnimalProfile* ap = new AnimalProfile();
        cp->initialize(client);
        ap->initialize(animal);
        cp->readOnly(true);
        ap->readOnly(true);
        cp->show();
        ap->show();
    }else{
        QMessageBox::critical(NULL, "warning", "Please select the pair of result you want to view!", QMessageBox::Yes, QMessageBox::Yes);
    }
}

void Control::requestUpdate(){
    update();
}

void Control::exitSystem(){
    qApp->quit();
}
