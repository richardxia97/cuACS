#ifndef CONTROL_H
#define CONTROL_H

#include <QApplication>
#include <QMainWindow>
#include <QTimer>
#include "staffview.h"
#include "clientview.h"
#include "animalprofile.h"
#include "animal.h"
#include "list.h"
#include "animalmanagement.h"
#include "clientmanagement.h"
#include <iostream>
#include <QString>
#include "view.h"
#include "login.h"
#include <QMessageBox>
#include "addclient.h"
#include "clientprofile.h"
#include "matching.h"


using namespace std;

class Control: public QObject
{
    Q_OBJECT
public:
    Control(){}
    ~Control();
    int launch(int argc, char *argv[]);

private:
    AnimalManagement am;
    ClientManagement cm;
    //HumanManagement hm;
    //Matching matching;
    View* view;
    LogIn *lg;

    //-1   staff|   clientID    client
    int identity = -1;
    Matching matching;
    std::vector<UnitOfMatching> matchingResult;

    void update();
    void receiveNewAnimal(Animal*);
    void receiveNewClient(Client*);
    void requestAddAnimal();
    void requestAddClient();
    void requestEditAnimal();
    void requestViewAnimalDetails();
    void requestLogOut();
    void requestLogIn(string,string);
    void requestEditClientProfile();
    void requestViewClientDetails();
    void requestUpdate();
    void requestMatch();
    void requestViewMatchDetails();
    void exitSystem();

signals:

};

#endif // CONTROL_H
