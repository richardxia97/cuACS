#include "animalprofile.h"
#include "ui_animalprofile.h"

#define MAMMAL 0
#define BIRD 1
#define REPTILE 2
#define BATRACHIA 3
#define OTHERS 4

#define CUB 0
#define MATURE 1
#define ELDER 2

#define TESTY 0
#define MIDDLE 1
#define MILD 2

#define ACTIVE 0
#define QUIET 1
#define SHY 2
#define LAZY 3
#define FRIENDLY 4

#define GREGARIOUS 0
#define SOLOTARY 1
#define BOTH 2

#define LOWSUGAR 0
#define LOWSALT 1
#define UNCOOKED 2
#define LOWFAT 3
#define ONLYLIQUID 4

#define GUIDEANIMAL 0
#define ANIMALTHERAPY 1
#define CHILDRENCARE 2
#define NONEOFTHOSESERVICE 3

#define SIMPLEGESTURECOMMANDS 0
#define SIMPLEVERBALCOMMANDS 1
#define COMPLEXVERABLCOMMANDS 2
#define NONEOFTHOSEINTELLIGENCE 3

#define ACCIDENCE 0
#define BEABUNDANT 1
#define MALTREAT 2
#define NONEOFTHOSEDISORDER 3

#define BEACTIVEATDAYLIGHT 0
#define BEACTIVEATNIGHT 1
#define ALWAYSSLEEPYWHOLLEDAY 2
#define ALWAYSACTIVEWHOLEDAY 3

#define GOODABILITY 0
#define NEEDSOMETIMES 1
#define NEEDALONGTIME 2


#define PREVIOUSOWNER 0
#define HOMELESS 1
#define LABORATORY 2
#define RESCUE 3





AnimalProfile::AnimalProfile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AnimalProfile)
{
    ui->setupUi(this);
    //gender group

    genderGroup = new QButtonGroup(this);
    genderGroup->addButton(ui->male,0);
    genderGroup->addButton(ui->femina,1);


}

AnimalProfile::~AnimalProfile()
{
    delete ui;
    delete genderGroup;
}

void AnimalProfile::initialize(Animal *animal){
    theAnimal = animal;
    PhysicalAttributes pa = animal->pa;
    NonPhysicalAttributes npa = animal->npa;

    ui->AID->setText(QString::number(animal->getAnimalID()));
    ui->animalName->setText(QString::fromStdString(animal->getAnimalName()));
    pa.getGender()? ui->male->setChecked(true): ui->femina->setChecked(true);
    ui->species->setText(QString::fromStdString(pa.getSpecies()));
    ui->classfication->setCurrentIndex(pa.getClassification());
    ui->age->setCurrentIndex(pa.getAgeStage());
    ui->aggressvity->setCurrentIndex(npa.getAggresivity());
    if(npa.getPersonality()[0]){
        ui->active->setChecked(true);
    }
    if(npa.getPersonality()[1]){
        ui->quiet->setChecked(true);
    }
    if(npa.getPersonality()[2]){
        ui->shy->setChecked(true);
    }
    if(npa.getPersonality()[3]){
        ui->lazy->setChecked(true);
    }
    if(npa.getPersonality()[4]){
        ui->friendly->setChecked(true);
    }
    ui->sociality->setCurrentIndex(npa.getSociality());
    if(npa.getDiet()[0]){
        ui->lowsuger->setChecked(true);
    }
    if(npa.getDiet()[1]){
        ui->lowsalt->setChecked(true);
    }
    if(npa.getDiet()[2]){
        ui->uncooked->setChecked(true);
    }
    if(npa.getDiet()[3]){
        ui->lowfat->setChecked(true);
    }
    if(npa.getDiet()[4]){
        ui->onlyliquid->setChecked(true);
    }
    ui->service->setCurrentIndex(npa.getServiceability());
    ui->intelligence->setCurrentIndex(npa.getIntelligence());
    ui->disorder->setCurrentIndex(npa.getPsychologyDisorder());
    ui->dailyroutine->setCurrentIndex(npa.getDailyRoutine());
    ui->sheltertime->setText(QString::number(npa.getTimeOfShelter()));
    ui->adaptability->setCurrentIndex(npa.getAdaptability());
    ui->resource->setCurrentIndex(npa.getResource());
    ui->investment->setCurrentIndex(npa.getInvestment());

}
void AnimalProfile::readOnly(bool b){

    if(b){

        ui->l_name->setText(ui->l_name->text()+"      "+ui->animalName->text());
        ui->animalName->setVisible(false);


        ui->femina->setEnabled(false);


        ui->l_species->setText(ui->l_species->text()+"      "+ui->species->text());
        ui->species->setVisible(false);


        ui->l_classfication->setText(ui->l_classfication->text()+"      "+ui->classfication->currentText());
        ui->classfication->setVisible(false);


        ui->l_age->setText(ui->l_age->text()+"      "+ui->age->currentText());
        ui->age->setVisible(false);


        ui->l_aggressivity->setText(ui->l_aggressivity->text()+"      "+ui->aggressvity->currentText());
        ui->aggressvity->setVisible(false);


        ui->active->setEnabled(false);
        ui->quiet->setEnabled(false);
        ui->shy->setEnabled(false);
        ui->lazy->setEnabled(false);
        ui->friendly->setEnabled(false);

        ui->sociality->setEnabled(false);
        ui->l_sociality->setText(ui->l_sociality->text()+"      "+ui->sociality->currentText());
        ui->sociality->setVisible(false);

        ui->uncooked->setEnabled(false);
        ui->onlyliquid->setEnabled(false);
        ui->lowsuger->setEnabled(false);
        ui->lowfat->setEnabled(false);
        ui->lowsalt->setEnabled(false);

        ui->service->setEnabled(false);
        ui->l_serviceability->setText(ui->l_serviceability->text()+"      "+ui->service->currentText());
        ui->service->setVisible(false);

        ui->intelligence->setEnabled(false);
        ui->l_interaction->setText(ui->l_interaction->text()+"      "+ui->intelligence->currentText());
        ui->intelligence->setVisible(false);

        ui->disorder->setEnabled(false);
        ui->l_disorder->setText(ui->l_disorder->text()+"      "+ui->disorder->currentText());
        ui->disorder->setVisible(false);

        ui->dailyroutine->setEnabled(false);
        ui->l_routine->setText(ui->l_routine->text()+"      "+ui->dailyroutine->currentText());
        ui->dailyroutine->setVisible(false);

        ui->sheltertime->setEnabled(false);
        ui->l_time->setText(ui->l_time->text()+"      "+ui->sheltertime->text());
        ui->sheltertime->setVisible(false);

        ui->adaptability->setEnabled(false);
        ui->l_adaptability->setText(ui->l_adaptability->text()+"      "+ui->adaptability->currentText());
        ui->adaptability->setVisible(false);

        ui->resource->setEnabled(false);
        ui->l_resource->setText(ui->l_resource->text()+"      "+ui->resource->currentText());
        ui->resource->setVisible(false);

        ui->investment->setEnabled(false);
        ui->l_investment->setText(ui->l_investment->text()+"      "+ui->investment->currentText());
        ui->investment->setVisible(false);

    }

}


void AnimalProfile::on_buttonBox_accepted()
{
    int per[5] = {0,0,0,0,0};
    int diet[5] = {0,0,0,0,0};
    if(ui->lowsuger->isChecked()){
        diet[0]=1;
    }
    if(ui->lowsalt->isChecked()){
        diet[1]=1;
    }
    if(ui->uncooked->isChecked()){
        diet[2]=1;
    }
    if(ui->lowfat->isChecked()){
        diet[3]=1;
    }
    if(ui->onlyliquid->isChecked()){
        diet[4]=1;
    }
    if(ui->active->isChecked()){
        per[0]=1;
    }
    if(ui->quiet->isChecked()){
        per[1]=1;
    }
    if(ui->shy->isChecked()){
        per[2]=1;
    }
    if(ui->lazy->isChecked()){
        per[3]=1;
    }
    if(ui->friendly->isChecked()){
        per[4]=1;
    }

    theAnimal->setAnimalName(ui->animalName->text().toStdString());

    if(ui->male->isChecked()){
        theAnimal->pa.setGender(true);
    }else{
        theAnimal->pa.setGender(false);
    }
    theAnimal->pa.setSpecies(ui->species->text().toStdString());
    theAnimal->pa.setClassification(ui->classfication->currentIndex());
    theAnimal->pa.setAgeStage(ui->age->currentIndex());
    theAnimal->npa.setAggresivity(ui->aggressvity->currentIndex());
    theAnimal->npa.setPersonality(per);
    theAnimal->npa.setSociality(ui->sociality->currentIndex());
    theAnimal->npa.setDiet(diet);
    theAnimal->npa.setServiceability(ui->service->currentIndex());
    theAnimal->npa.setIntelligence(ui->intelligence->currentIndex());
    theAnimal->npa.setPsychologyDisorder(ui->disorder->currentIndex());
    theAnimal->npa.setDailyRoutine(ui->dailyroutine->currentIndex());
    theAnimal->npa.setTimeOfShelter(ui->sheltertime->text().toInt());
    theAnimal->npa.setAdaptability(ui->adaptability->currentIndex());
    theAnimal->npa.setResource(ui->resource->currentIndex());
    theAnimal->npa.setInvestment(ui->investment->currentIndex());

    emit newAnimal(theAnimal);
}

void AnimalProfile::on_tip_clicked()
{
    QMessageBox::about(0,"Tip","The investment necessary to adopt the animal, such as the purchase of equipments.");
}
