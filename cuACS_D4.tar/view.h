#ifndef VIEW_H
#define VIEW_H

#include <QMainWindow>
#include "list.h"
#include "animal.h"
#include "client.h"
#include "unitOfMatching.h"

namespace Ui {
class View;
}

class View : public QMainWindow
{
    Q_OBJECT

public:
    explicit View(QWidget *parent = 0);
    ~View();
    virtual int getSelectedAnimalIndex() = 0;
    virtual void updateAnimalList(List<Animal>&) = 0;
    virtual void updateClientList(List<Client>&) = 0;
    virtual int getSelectedClientIndex() = 0;
    virtual void updateMatchResult(std::vector<UnitOfMatching>) = 0;
    virtual int getSelectedMatchPairIndex() = 0;

signals:
    void viewAnimalDetails();
    void addAnimal();
    void editAnimal();
    void logOut();
    void addClient();
    void editClientProfile();
    void viewClientDetails();
    void viewMatchingDetial();
    void matching();

private:
    Ui::View *ui;
};

#endif // VIEW_H
