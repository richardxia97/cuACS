//NonPhysicalAttributes.cpp
#include "nonphysicalattributes.h"


NonPhysicalAttributes::NonPhysicalAttributes(){
    personality[0] = 0;
    personality[1] = 0;
    personality[2] = 0;
    personality[3] = 0;
    personality[4] = 0;
    diet[0] = 0;
    diet[1] = 0;
    diet[2] = 0;
    diet[3] = 0;
    diet[4] = 0;
    aggresivity = 0;
    sociality = 0;
    serviceability = 0;
    intelligence = 0;
    psychologydisorder = 0;
    dailyroutine = 0;
    timeOfShelter = 0;
    adaptability = 0;
    resource = 0;
    investment = 0;
}

int NonPhysicalAttributes::getAggresivity(){
  return aggresivity;

}
int* NonPhysicalAttributes::getPersonality(){
  return personality;
}
int  NonPhysicalAttributes::getSociality(){
  return sociality;
}
int* NonPhysicalAttributes::getDiet(){
  return diet;
}
int NonPhysicalAttributes::getServiceability(){
  return serviceability;
}
int NonPhysicalAttributes::getIntelligence(){
  return intelligence;
}
int NonPhysicalAttributes::getPsychologyDisorder(){
  return psychologydisorder;
}
int NonPhysicalAttributes::getDailyRoutine(){
  return dailyroutine;
}
int NonPhysicalAttributes::getTimeOfShelter(){
  return timeOfShelter;
}
int NonPhysicalAttributes::getAdaptability(){
  return adaptability;
}
int NonPhysicalAttributes::getResource(){
  return resource;
}
int NonPhysicalAttributes::getInvestment(){
  return investment;
}

void NonPhysicalAttributes::setAggresivity(int a){
  aggresivity = a;
}
void NonPhysicalAttributes::setPersonality(int* p){
  personality[0] = p[0];
  personality[1] = p[1];
  personality[2] = p[2];
  personality[3] = p[3];
  personality[4] = p[4];

}
void NonPhysicalAttributes::setSociality(int s){
  sociality = s;
}
void NonPhysicalAttributes::setDiet(int* d){
  diet[0] = d[0];
  diet[1] = d[1];
  diet[2] = d[2];
  diet[3] = d[3];
  diet[4] = d[4];
}
void NonPhysicalAttributes::setServiceability(int s){
  serviceability = s;
}
void NonPhysicalAttributes::setIntelligence(int i){
  intelligence = i;
}
void NonPhysicalAttributes::setPsychologyDisorder(int p){
  psychologydisorder = p;
}
void NonPhysicalAttributes::setDailyRoutine(int d){
  dailyroutine = d;
}
void NonPhysicalAttributes::setTimeOfShelter(int t){
  timeOfShelter = t;
}
void NonPhysicalAttributes::setAdaptability(int a){
  adaptability = a;
}
void NonPhysicalAttributes::setResource (int r){
  resource = r;
}

void NonPhysicalAttributes::setInvestment(int i){
    investment = i;
}
