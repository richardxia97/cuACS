#ifndef PERSONALINFO_H
#define PERSONALINFO_H
#include <iostream>
using namespace std;
class MatchingInfo
{
public:
    MatchingInfo();
    void setHasChild(bool b){hasChild = b;}
    void setHasElder(bool b){hasElder = b;}
    void setFamilyMemeber(int i){familyMember = i;}
    void setFirstName(string name){firstName = name;}
    void setFamilyName(string name){familyName = name;}
    void setAge(int a){age = a;}
    void setRoutine(int r){routine = r;}
    void setExperienced(bool e){experienced = e;}
    void setAvailableTime(int a){availableTime = a;}
    void setIncome(int i){income = i;}
    void setPersonality(int* p){
        for(int i = 0; i<5;i++){
            personality[i] = p[i];
        }
    }
    void setRequirement(int r){specialRequire = r;}
    void setWillingness(bool w){willingness = w;}

    bool getHasChild(){return hasChild;}
    bool getHasElder(){return hasElder;}
    int getFamilyMemeber(){return familyMember;}
    string getFirstName(){return firstName;}
    string getFamilyName(){return familyName;}
    int getAge(){return age;}
    int getRoutine(){return routine;}
    bool getExperienced(){return experienced;}
    int getAvailableTime(){return availableTime;}
    int getIncome(){return income;}
    int* getPersonality(){return personality;}
    int getRequirement(){return specialRequire;}
    bool getWillingness(){return willingness;}

private:
    bool hasChild = false;
    bool hasElder = false;
    int familyMember = 0;
    string firstName = "";
    string familyName = "";
    int age = 0;
    int routine = 0;
    bool experienced = false;
    int availableTime = 0;
    int income = 0;
    int personality[5] = {0,0,0,0,0};
    int specialRequire = 3;
    bool willingness = false;

};

#endif // PERSONALINFO_H
