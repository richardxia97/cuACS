#include "control.h"


int main(int argc, char *argv[])
{

    Control control;
    control.launch(argc, argv);
}
