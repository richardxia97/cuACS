#include "unitOfMatching.h"

UnitOfMatching::UnitOfMatching(){}

UnitOfMatching::UnitOfMatching(int a,string aN,int c,string cN)
{
    aid = a;
    aName = aN;
    cid = c;
    cName = cN;
}
