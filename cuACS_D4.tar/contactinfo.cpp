#include "contactinfo.h"

ContactInfo::ContactInfo()
{
    phone = "";
    email = "";
    address = "";
    postCode = "";
}


string ContactInfo::getAddress(){return address;}
string ContactInfo::getPhone(){return phone;}
string ContactInfo::getEmail(){return email;}
string ContactInfo::getPostCode(){return postCode;}
void ContactInfo::setAddress(string a){address = a;}
void ContactInfo::setPhone(string p){phone = p;}
void ContactInfo::setEmail(string e){email = e;}
void ContactInfo::setPostCode(string p){postCode = p;}
