//List.h
#ifndef LIST_H
#define LIST_H
#include <iostream>


template <class T>
class node {
public:
    T* obj;
    node *next;
};


template <class T>
class List
{
private:
    node<T> *head, *tail;
    int length;

public:
    List();
    ~List();
    int getLength();
    T* get(int index);
    void clear();
    node<T>* getHeadNode();
    node<T>* getTailNode();
    void add(T*);

};

template <class T>
List<T>::List(){
      head=NULL;
      tail=NULL;
      length = 0;
}
template <class T>
List<T>::~List(){
    node<T>* current,*temp;
    current = head;
    while(current != NULL){
        temp = current->next;
        delete current->obj;
        delete current;
        current = temp;
    }
}
template <class T>
void List<T>::clear(){
    node<T>* current,*temp;
    current = head;
    while(current != NULL){
        temp = current->next;
        delete current->obj;
        delete current;
        current = temp;
    }
    head = current;
    tail = current;
}

template <class T>
void List<T>::add(T* o) {
      node<T> *temp=new node<T>;
      temp->obj=o;
      temp->next=NULL;
      length++;
      if(head==NULL)
      {
        head=temp;
        tail=temp;
        //temp=NULL;
      }
      else
      {
        tail->next=temp;
        tail=temp;
      }
}

template <class T>
T* List<T>::get(int index){
    node<T> *temp = head;
    for (int i = 0; i < index; i++)
      temp = temp->next;
    return temp->obj;
  }

template <class T>
node<T>* List<T>::getHeadNode(){
      return head;
  }
template <class T>
node<T>* List<T>::getTailNode(){
      return tail;
  }

template <class T>
int List<T>::getLength(){
    return length;
}
#endif
