#include "clientprofile.h"
#include "ui_clientprofile.h"

ClientProfile::ClientProfile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ClientProfile)
{
    ui->setupUi(this);
    ui->l_uName->setVisible(false);
    ui->l_phone->setVisible(false);
    ui->l_email->setVisible(false);
    ui->l_address->setVisible(false);
    ui->l_post->setVisible(false);
    ui->l_fmember->setVisible(false);
    ui->l_firstname->setVisible(false);
    ui->l_familyname->setVisible(false);
    ui->l_age->setVisible(false);
    ui->l_routine->setVisible(false);
    ui->l_availableTime->setVisible(false);
    ui->l_income->setVisible(false);
    ui->l_personalities->setVisible(false);
    ui->l_service->setVisible(false);
}

ClientProfile::~ClientProfile()
{
    delete ui;
}


void ClientProfile::on_tip_clicked()
{
     QMessageBox::about(0,"Tip","The characters of animal you prefer to adopt.");
}


void ClientProfile::initialize(Client *c){
    client = c;
    ui->l_uID->setText(QString::number(client->getClientID()));

    ui->l_uName->setText(QString::fromStdString(client->getClientName()));
    ui->username->setText(QString::fromStdString(client->getClientName()));

    ui->l_phone->setText(QString::fromStdString(client->ci.getPhone()));
    ui->phone->setText(QString::fromStdString(client->ci.getPhone()));

    ui->l_email->setText(QString::fromStdString(client->ci.getEmail()));
    ui->email->setText(QString::fromStdString(client->ci.getEmail()));

    ui->l_address->setText(QString::fromStdString(client->ci.getAddress()));
    ui->address->setText(QString::fromStdString(client->ci.getAddress()));

    ui->l_post->setText(QString::fromStdString(client->ci.getPostCode()));
    ui->postCode->setText(QString::fromStdString(client->ci.getPostCode()));

    ui->hasChild->setChecked(client->mi.getHasChild());
    ui->hasElder->setChecked(client->mi.getHasElder());


    ui->familyMember->setCurrentIndex(client->mi.getFamilyMemeber());
    ui->l_fmember->setText(ui->familyMember->currentText());

    ui->firstName->setText(QString::fromStdString(client->mi.getFirstName()));
    ui->l_firstname->setText(QString::fromStdString(client->mi.getFirstName()));

    ui->familyName->setText(QString::fromStdString(client->mi.getFamilyName()));
    ui->l_familyname->setText(QString::fromStdString(client->mi.getFamilyName()));

    ui->age->setCurrentIndex(client->mi.getAge());
    ui->l_age->setText(ui->age->currentText());

    ui->routine->setCurrentIndex(client->mi.getRoutine());
    ui->l_routine->setText(ui->routine->currentText());

    ui->experienced->setChecked(client->mi.getExperienced());

    ui->availableTime->setCurrentIndex(client->mi.getAvailableTime());
    ui->l_availableTime->setText(ui->availableTime->currentText());

    ui->income->setCurrentIndex(client->mi.getIncome());
    ui->l_income->setText(ui->income->currentText());

    ui->active->setChecked(client->mi.getPersonality()[0]);
    ui->quiet->setChecked(client->mi.getPersonality()[1]);
    ui->shy->setChecked(client->mi.getPersonality()[2]);
    ui->lazy->setChecked(client->mi.getPersonality()[3]);
    ui->friendly->setChecked(client->mi.getPersonality()[4]);
    string personalities = "";
    personalities += ui->active->isChecked()? "active  ":"";
    personalities += ui->quiet->isChecked()? "quiet  ":"";
    personalities += ui->shy->isChecked()? "shy  ":"";
    personalities += ui->lazy->isChecked()? "lazy ":"";
    personalities += ui->friendly->isChecked()? "friendly":"";
    ui->l_personalities->setText(QString::fromStdString(personalities));

    ui->service->setCurrentIndex(client->mi.getRequirement());
    ui->l_service->setText(ui->service->currentText());

    ui->specialcare->setChecked(client->mi.getWillingness());
}

void ClientProfile::readOnly(bool b){
    if(b){
        ui->hasChild->setDisabled(true);
        ui->hasElder->setDisabled(true);
        ui->experienced->setDisabled(true);
        ui->specialcare->setDisabled(true);


        ui->l_uName->setVisible(true);
        ui->l_phone->setVisible(true);
        ui->l_email->setVisible(true);
        ui->l_address->setVisible(true);
        ui->l_post->setVisible(true);
        ui->l_fmember->setVisible(true);
        ui->l_firstname->setVisible(true);
        ui->l_familyname->setVisible(true);
        ui->l_age->setVisible(true);
        ui->l_routine->setVisible(true);
        ui->l_availableTime->setVisible(true);
        ui->l_income->setVisible(true);
        ui->l_personalities->setVisible(true);
        ui->l_service->setVisible(true);


        ui->username->setVisible(false);
        ui->phone->setVisible(false);
        ui->email->setVisible(false);
        ui->address->setVisible(false);
        ui->postCode->setVisible(false);
        ui->familyMember->setVisible(false);
        ui->firstName->setVisible(false);
        ui->familyName->setVisible(false);
        ui->age->setVisible(false);
        ui->routine->setVisible(false);
        ui->availableTime->setVisible(false);
        ui->income->setVisible(false);
        ui->lazy->setVisible(false);
        ui->shy->setVisible(false);
        ui->active->setVisible(false);
        ui->quiet->setVisible(false);
        ui->friendly->setVisible(false);
        ui->service->setVisible(false);

    }
}

void ClientProfile::on_ok_clicked()
{

    client->setClientName(ui->username->text().toStdString());
    client->ci.setPhone(ui->phone->text().toStdString());
    client->ci.setEmail(ui->email->text().toStdString());
    client->ci.setAddress(ui->address->toPlainText().toStdString());
    client->ci.setPostCode(ui->postCode->text().toStdString());
    client->mi.setHasChild(ui->hasChild->isChecked());
    client->mi.setHasElder(ui->hasElder->isChecked());
    client->mi.setFamilyMemeber(ui->familyMember->currentIndex());
    client->mi.setFirstName(ui->firstName->text().toStdString());
    client->mi.setFamilyName(ui->familyName->text().toStdString());
    client->mi.setAge(ui->age->currentIndex());
    client->mi.setRoutine(ui->routine->currentIndex());
    client->mi.setExperienced(ui->experienced->isChecked());
    client->mi.setAvailableTime(ui->availableTime->currentIndex());
    client->mi.setIncome(ui->income->currentIndex());

    int p[5];
    p[0] = ui->active->isChecked()? 1:0;
    p[1] = ui->quiet->isChecked()? 1:0;
    p[2] = ui->shy->isChecked()? 1:0;
    p[3] = ui->lazy->isChecked()? 1:0;
    p[4] = ui->friendly->isChecked()? 1:0;
    client->mi.setPersonality(p);

    client->mi.setRequirement(ui->service->currentIndex());
    client->mi.setWillingness(ui->specialcare->isChecked());

    emit update();
    this->close();
}

void ClientProfile::on_tip_2_clicked()
{
    QMessageBox::about(0,"Tip","Adopting some animals may create finalcial pressure to you.");
}

void ClientProfile::on_tip_3_clicked()
{
    QMessageBox::about(0,"Tip","The special requirement on service capability of adopting animal.");
}
