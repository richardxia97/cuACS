//AnimalManagement.cpp
#include "animalmanagement.h"


int AnimalManagement::loadAnimalData(string fileName){
    animalList.clear();
    QString data;
    QFile myfile(QString::fromStdString(fileName));
    myfile.open(QIODevice::ReadOnly);
    QTextStream txtInput(&myfile);
    Animal* animal;
    int temp[5];
    while(!txtInput.atEnd()){
      animal = new Animal();
      data = txtInput.readLine();
      animal->setAnimalID(data.toInt());
      data = txtInput.readLine();
      animal->setAnimalName(data.toStdString());
      data = txtInput.readLine();
      animal->pa.setGender(data.toInt());
      data = txtInput.readLine();
      animal->pa.setSpecies(data.toStdString());
      data = txtInput.readLine();
      animal->pa.setClassification(data.toInt());
      data = txtInput.readLine();
      animal->pa.setAgeStage(data.toInt());
      data = txtInput.readLine();
      animal->npa.setAggresivity(data.toInt());


      for(int i =0;i<5;i++){
          data = txtInput.readLine();
          temp[i] = data.toInt();
      }
      animal->npa.setPersonality(temp);

      data = txtInput.readLine();
      animal->npa.setSociality(data.toInt());

      for(int i =0;i<5;i++){
          data = txtInput.readLine();
          temp[i] = data.toInt();
      }
      animal->npa.setDiet(temp);

      data = txtInput.readLine();
      animal->npa.setServiceability(data.toInt());
      data = txtInput.readLine();
      animal->npa.setIntelligence(data.toInt());
      data = txtInput.readLine();
      animal->npa.setPsychologyDisorder(data.toInt());
      data = txtInput.readLine();
      animal->npa.setDailyRoutine(data.toInt());
      data = txtInput.readLine();
      animal->npa.setTimeOfShelter(data.toInt());
      data = txtInput.readLine();
      animal->npa.setAdaptability(data.toInt());
      data = txtInput.readLine();
      animal->npa.setResource(data.toInt());
      data = txtInput.readLine();
      animal->npa.setInvestment(data.toInt());
      animalList.add(animal);
  }
  myfile.close();
  return 0;
}

int AnimalManagement::saveAnimalData(string fileName){
  QFile myfile(QString::fromStdString((fileName)));
  myfile.open(QIODevice::WriteOnly);
  QTextStream txtOutput(&myfile);
  node<Animal>* temp=animalList.getHeadNode();
  Animal* animal;
  while (temp != NULL){
      animal = temp->obj;
      txtOutput<<animal->getAnimalID()<<"\n";
      txtOutput<<QString::fromStdString(animal->getAnimalName())<<"\n";
      txtOutput<<animal->pa.getGender()<<"\n";
      txtOutput<<QString::fromStdString(animal->pa.getSpecies())<<"\n";
      txtOutput<<animal->pa.getClassification()<<"\n";
      txtOutput<<animal->pa.getAgeStage()<<"\n";
      txtOutput<<animal->npa.getAggresivity()<<"\n";
      for(int i =0; i<5;i++){
          txtOutput<<animal->npa.getPersonality()[i]<<"\n";
      }
      txtOutput<<animal->npa.getSociality()<<"\n";
      for(int i =0; i<5;i++){
          txtOutput<<animal->npa.getDiet()[i]<<"\n";
      }
      txtOutput<<animal->npa.getServiceability()<<"\n";
      txtOutput<<animal->npa.getIntelligence()<<"\n";
      txtOutput<<animal->npa.getPsychologyDisorder()<<"\n";
      txtOutput<<animal->npa.getDailyRoutine()<<"\n";
      txtOutput<<animal->npa.getTimeOfShelter()<<"\n";
      txtOutput<<animal->npa.getAdaptability()<<"\n";
      txtOutput<<animal->npa.getResource()<<"\n";
      txtOutput<<animal->npa.getInvestment()<<"\n";
      temp = temp->next;
  }
  myfile.close();
  return 0;
}
