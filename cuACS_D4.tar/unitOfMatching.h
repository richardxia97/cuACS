#ifndef UNITOFMATCHING_H
#define UNITOFMATCHING_H

#include <iostream>

using namespace std;

// store a pair of animal-client after matching operation
class UnitOfMatching
{
public:
    UnitOfMatching();
    UnitOfMatching(int,string,int,string);
    int aid;
    string aName;
    int cid;
    string cName;
};

#endif // UNITOFMATCHING_H
