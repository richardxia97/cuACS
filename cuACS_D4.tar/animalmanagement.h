//AnimalManagement.h
#ifndef ANIMALMANAGEMENT_H
#define ANIMALMANAGEMENT_H
#include "animal.h"
#include "list.h"
#include <fstream>
#include <iostream>
#include <QFile>
#include <QTextStream>


class AnimalManagement {

public:
  int loadAnimalData(string fileName);
  int saveAnimalData(string fileName);

  List<Animal> animalList;

};

#endif
