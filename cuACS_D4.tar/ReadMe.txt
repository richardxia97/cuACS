﻿###############################################################################################



CuACS aims to contribute to animal welfare.

Animals to be adopted will be entered by staff.

Users with adoption intention can log in the system for information entry.

The system will match animals with adopters when appropriate.



###############################################################################################



Envornment:

	-operation system:Linux family


To install:

	complie the code by typing in:
 
		make

To launch:

	by typing in:
		./cuACS



To test:

	1 Staff account and 20 Client accounts have been built in this system:
		(For the convenience of testing, the passwords of 
					all built-in user accounts are set to 888888)

	
	User name 	Password	Identify
______________________________________________________________
	admin		admin		Staff
______________________________________________________________
	Bob		888888		Client
	Ted3		888888		Client
	Van17		888888		Client
	4Bob		888888		Client
	Huni26		888888		Client
	...		...		...

###############################################################################################



CopyRight:

	SegmentationFault

		-Xiran Zhou; 		101096642

        	-Liyongshi Chen:	101022029

        	-Richard Xia: 		101007519

        	-Weihang Chen: 		101084865



###############################################################################################
