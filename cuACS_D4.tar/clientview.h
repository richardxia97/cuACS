#ifndef CLIENTVIEW_H
#define CLIENTVIEW_H

#include <QMainWindow>
#include <QSignalMapper>
#include "animal.h"
#include "list.h"
#include "view.h"
#include <QMessageBox>

using namespace std;



namespace Ui {
class ClientView;
}

class ClientView : public  View
{
    Q_OBJECT

public:
    explicit ClientView(QWidget *parent = 0);
    ~ClientView();
    int getSelectedAnimalIndex();
    void updateAnimalList(List<Animal>&);
    void updateClientList(List<Client>&){}
    int getSelectedClientIndex(){return 0;}
    void updateMatchResult(std::vector<UnitOfMatching>){return;}
    int getSelectedMatchPairIndex(){return 0;}

private:
    Ui::ClientView *ui;


private slots:

    void on_viewAnimalDetails_clicked();
    void on_editprofile_clicked();
    void on_logOut_clicked();
};

#endif // CLIENTVIEW_H
