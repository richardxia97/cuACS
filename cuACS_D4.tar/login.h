#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>

using namespace std;

namespace Ui {
class LogIn;
}

class LogIn : public QDialog
{
    Q_OBJECT

public:
    explicit LogIn(QWidget *parent = 0);
    ~LogIn();

private slots:
    void on_exit_clicked();

    void on_logIn_clicked();

private:
    Ui::LogIn *ui;

signals:
    void login(string, string);
    void exitSystem();
};

#endif // LOGIN_H
