#include "staffview.h"
#include "ui_staffview.h"

#define HANGUP -1
#define ADDANIMAL 1
#define EDITANIMAL 2
#define VIEWANIMALDETAILS 3
#define ADDCLIENT 4
#define VIEWCLIENTDETAILS 5


StaffView::StaffView(QWidget *parent) :
    View(parent)

{
    ui = new Ui::StaffView();
    ui->setupUi(this);

    // set window

    this->setWindowIcon(QIcon(":/resource/logo.ico"));




    //set animal table
    QStringList header;
    header<<"ID"<<"name"<<"Description";
    ui->animalList->setHorizontalHeaderLabels(header);
    ui->animalList->horizontalHeader()->setStretchLastSection(true);

    ui->animalList->setColumnWidth(0, 40);
    ui->animalList->setColumnWidth(1, 100);


    ui->animalList->setSelectionBehavior ( QAbstractItemView::SelectRows);
    ui->animalList->setSelectionMode ( QAbstractItemView::SingleSelection);

    //set client table
    header<<"UID"<<"Uer Name"<<"Contact Information";
    ui->clientList->setHorizontalHeaderLabels(header);
    ui->clientList->horizontalHeader()->setStretchLastSection(true);

    ui->clientList->setColumnWidth(0, 40);
    ui->clientList->setColumnWidth(1, 100);

    ui->clientList->setSelectionBehavior ( QAbstractItemView::SelectRows);
    ui->clientList->setSelectionMode ( QAbstractItemView::SingleSelection);

    //set view matching result disable
    ui->viewMatchDetails->setDisabled(true);

    ui->matchList->horizontalHeader()->setStretchLastSection(true);
    ui->matchList->setSelectionBehavior ( QAbstractItemView::SelectRows);
    ui->matchList->setSelectionMode ( QAbstractItemView::SingleSelection);


}

StaffView::~StaffView()
{
    delete ui;
}



int StaffView::getSelectedAnimalIndex(){
    bool focus = ui->animalList->isItemSelected(ui->animalList->currentItem());
    int row = ui->animalList->currentRow();
    return focus? row:-1;
}

void StaffView::updateAnimalList(List<Animal>& al){
    node<Animal>* temp = al.getHeadNode();
    QTableWidgetItem* content;
    int row;
    ui->animalList->clear();
    ui->animalList->setRowCount(0);
    QStringList header;
    header<<"ID"<<"name"<<"Description";
    ui->animalList->setHorizontalHeaderLabels(header);
    ui->animalList->horizontalHeader()->setStretchLastSection(true);
    Animal* animal;
    while(temp!=NULL){
        row = ui->animalList->rowCount();
        ui->animalList->setRowCount(row+1);
        ui->animalList->setRowHeight(row,20);
        animal = temp->obj;
        content = new QTableWidgetItem(QString::fromStdString(to_string(animal->getAnimalID())));
        ui->animalList->setItem(row,0,content);
        content = new QTableWidgetItem(QString::fromStdString(animal->getAnimalName()));
        ui->animalList->setItem(row,1,content);
        content = new QTableWidgetItem(QString::fromStdString(animal->briefDescription()));
        ui->animalList->setItem(row,2,content);
        temp = temp->next;
    }
}


void StaffView::updateClientList(List<Client>& cl){
    node<Client>* temp = cl.getHeadNode();
    QTableWidgetItem* content;
    int row;
    ui->clientList->clear();
    ui->clientList->setRowCount(0);
    QStringList header;
    header<<"UID"<<"Uer Name"<<"Contact Information";
    ui->clientList->setHorizontalHeaderLabels(header);
    ui->clientList->horizontalHeader()->setStretchLastSection(true);
    Client* client;
    while(temp!=NULL){
        row = ui->clientList->rowCount();
        ui->clientList->setRowCount(row+1);
        ui->clientList->setRowHeight(row,20);
        client = temp->obj;
        content = new QTableWidgetItem(QString::fromStdString(to_string(client->getClientID())));
        ui->clientList->setItem(row,0,content);
        content = new QTableWidgetItem(QString::fromStdString(client->getClientName()));
        ui->clientList->setItem(row,1,content);
        content = new QTableWidgetItem(QString::fromStdString(client->briefDescription()));
        ui->clientList->setItem(row,2,content);
        temp = temp->next;
    }
}


void StaffView::updateMatchResult(std::vector<UnitOfMatching> matchingResult){

    if(matchingResult.size()>0){
        ui->viewMatchDetails->setDisabled(false);
    }else{
        ui->matchList->clear();
        ui->matchList->setColumnCount(1);
        ui->matchList->setRowCount(0);
        QStringList header;
        header<<"Error!";
        ui->matchList->setHorizontalHeaderLabels(header);
        ui->matchList->horizontalHeader()->setStretchLastSection(true);
        QTableWidgetItem* content = new QTableWidgetItem(QString::fromStdString("None suitable matching result"));
        ui->matchList->setRowCount(1);
        ui->matchList->setRowHeight(1,20);
        ui->matchList->setItem(0,0,content);
        return;
    }

    QTableWidgetItem* content;
    int row;
    ui->matchList->clear();
    ui->matchList->setColumnCount(2);
    ui->matchList->setRowCount(0);
    QStringList header;
    header<<"Animal"<<"Client";
    ui->matchList->setHorizontalHeaderLabels(header);
    ui->matchList->horizontalHeader()->setStretchLastSection(true);
    for(int i = 0;i<matchingResult.size();i++){
        row = ui->matchList->rowCount();
        ui->matchList->setRowCount(row+1);
        ui->matchList->setRowHeight(row,20);

        content = new QTableWidgetItem(QString::fromStdString(to_string(matchingResult[i].aid)+":"+matchingResult[i].aName));
        ui->matchList->setItem(row,0,content);
        content = new QTableWidgetItem(QString::fromStdString(to_string(matchingResult[i].cid)+":"+matchingResult[i].cName));
        ui->matchList->setItem(row,1,content);
    }

}

void StaffView::on_addAnimal_clicked()
{
    emit addAnimal();
}

void StaffView::on_editAnimal_clicked()
{
    emit editAnimal();
}



void StaffView::on_logOut_clicked()
{
    emit logOut();
}

void StaffView::on_viewAnimalDetails_clicked()
{
    emit viewAnimalDetails();
}


void StaffView::on_logOut_2_clicked()
{
     emit logOut();
}

void StaffView::on_addClient_clicked()
{
    emit addClient();
}

int StaffView::getSelectedClientIndex(){
    bool focus = ui->clientList->isItemSelected(ui->clientList->currentItem());
    int row = ui->clientList->currentRow();
    return focus? row:-1;
}

int StaffView::getSelectedMatchPairIndex(){
    bool focus = ui->matchList->isItemSelected(ui->matchList->currentItem());
    int row = ui->matchList->currentRow();
    return focus? row:-1;
}

void StaffView::on_viewClientDetails_clicked()
{
    emit viewClientDetails();
}

void StaffView::on_logOut_3_clicked()
{
    emit logOut();
}

void StaffView::on_match_clicked()
{
    emit matching();
}


void StaffView::on_viewMatchDetails_clicked()
{
    emit viewMatchingDetial();
}
