//NonPhysicalAttributes.h
#ifndef NONPHYSICALATTRIBUTES_H
#define NONPHYSICALATTRIBUTES_H

#include <iostream>
using namespace std;

class NonPhysicalAttributes
{
private:
    //NonPhysicalAttributes are stored as an integer measurement on a scale
    //i.e. Mood (0 - 9) (0 = Sad, 9 = Happy
    int personality[5]; //(0 - 4), (0 = active, 1 = quiet, 2 = shy, 3 = lazy, 4 = friendly)
    int diet[5]; //(9 - 4), (0 = low sugar, 1 = low salt, 2 = uncooked, 3 = low fat, 4 = only liquid)
    int aggresivity; //(0 - 2), (0 = testy, 1 = middle, 2 = mild)
    int sociality; //(0 - 2), (0 = gregarious, 1 = solitary, 2 = both)
    int serviceability; //(0 - 3) (0 = Guide dog, 1 = Animal Therapy, 2 + Children care, 3 = None of these)
    int intelligence; //(0 - 4) (0 = Simple gesture commands, 1 = Simple verbal commands, 2 = Complex verbal commands, 3 = Word repetition, 4 = None of these)
    int psychologydisorder; // (0 - 4) (0 = be abundant, 1 = used for experiments, 2 = maltreat, 3 = accident, 4 = none of these)
    int dailyroutine; // (0 - 4) (0 = be active )
    int timeOfShelter;
    int adaptability;
    int resource;
    int investment;

public:
  NonPhysicalAttributes();
  int getAggresivity();
  int* getPersonality();
  int getSociality();
  int* getDiet();
  int getServiceability();
  int getIntelligence();
  int getPsychologyDisorder();
  int getDailyRoutine();
  int getTimeOfShelter();
  int getAdaptability();
  int getResource();
  int getInvestment();
  void setAggresivity(int);
  void setPersonality(int*);
  void setSociality(int);
  void setDiet(int*);
  void setServiceability(int);
  void setIntelligence(int);
  void setPsychologyDisorder(int);
  void setDailyRoutine(int);
  void setTimeOfShelter(int);
  void setAdaptability(int);
  void setResource (int);
  void setInvestment(int);
};

#endif
