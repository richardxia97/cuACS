#ifndef ADDCLIENT_H
#define ADDCLIENT_H

#include <QDialog>
#include "client.h"
#include <QMessageBox>
#include <QRegExp>

namespace Ui {
class AddClient;
}

class AddClient : public QDialog
{
    Q_OBJECT

public:
    explicit AddClient(QWidget *parent = 0);
    ~AddClient();
    void setClientID(int);

private:
    Ui::AddClient *ui;
    Client* client;

signals:
    void newClient(Client*);
private slots:
    void on_cancel_clicked();
    void on_submit_clicked();
};

#endif // ADDCLIENT_H
