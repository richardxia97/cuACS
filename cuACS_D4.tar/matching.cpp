#include "matching.h"



Matching::Matching()
{

}
/*
bool Matching::Ccomparetor(ClientForMatching& c1,  ClientForMatching& c2){
    return c1.matchingAnimals.size()<c2.matchingAnimals.size();
}


bool Matching::Acomparetor(AnimalForMatching& a1, AnimalForMatching& a2){
    return a1.matchingClients.size()<a2.matchingClients.size();

*/
std::vector<UnitOfMatching> Matching::run(){

    while(1){

        // check whether there are none suitable pairs of animal-client
        bool isFinished = true;
        for(int i = 0; i<Matrix.size();i++){
            for(int j = 0 ;j<Matrix[0].size();j++){
                if(Matrix[i][j] != 0){
                    isFinished = false;
                }
                cout<<Matrix[i][j]<<" ";
            }
            cout<<endl;
        }
        if(isFinished){
            return matchResult;
        }

        // find the animal who has the minimun suitable partner wich means they are hard to macth
        // thus, match them first
        int MinIndexOfAnimal;
        int MinNumOfAnimal = 1000;
        for(int i = 0; i<Matrix.size();i++){
            int sum = 0;
            for(int j = 0 ;j<Matrix[0].size();j++){
                sum += Matrix[i][j];
            }
            if(sum<MinNumOfAnimal&&sum!=0){
                MinNumOfAnimal = sum;
                MinIndexOfAnimal = i;
            }
        }

        // find the client who has the minimun suitable partner as well
        int MinIndexOfClient;
        int MinNumOfClient = 1000;
        for(int j = 0; j<Matrix[0].size();j++){
            int sum = 0;
            for(int i = 0 ;i<Matrix.size();i++){
                sum += Matrix[i][j];
            }
            if(sum<MinNumOfClient&&sum!=0){
                MinNumOfClient = sum;
                MinIndexOfClient = j;
            }
        }

        cout<<MinIndexOfAnimal<<","<<MinIndexOfClient<<endl;
        // match the smaller one first
        if(MinIndexOfAnimal<MinIndexOfClient){
            // find its partner with the minimun suitable partner as well
            int MinIndexOfPartner;
            int MinNumOfPartner = 1000;
            for(int j = 0;j<Matrix[0].size();j++){
                if(Matrix[MinIndexOfAnimal][j] == 0)continue;
                int sum = 0;
                for(int i = 0 ;i<Matrix.size();i++){
                    sum += Matrix[i][j];
                }
                if(sum<MinNumOfPartner&&sum!=0){
                    MinNumOfPartner = sum;
                    MinIndexOfPartner = j;
                }
            }

           UnitOfMatching u = UnitOfMatching(al.get(MinIndexOfAnimal)->getAnimalID(),
                                              al.get(MinIndexOfAnimal)->getAnimalName(),
                                              cl.get(MinIndexOfPartner)->getClientID(),
                                              cl.get(MinIndexOfPartner)->getClientName());

            matchResult.push_back(u);


            // update the Matrix
            for(int i = 0;i<Matrix.size();i++){
                Matrix[i][MinIndexOfPartner] = 0;
            }
            for(int j = 0 ;j <Matrix[0].size();j++){
                Matrix[MinIndexOfAnimal][j] = 0;
            }
        }else{
            // find its partner with the minimun suitable partner as well
            int MinIndexOfPartner;
            int MinNumOfPartner = 1000;
            for(int i = 0;i<Matrix.size();i++){
                if(Matrix[i][MinIndexOfClient] == 0)continue;
                int sum = 0;
                for(int j = 0 ;j<Matrix.size();j++){
                    sum += Matrix[i][j];
                }
                if(sum<MinNumOfPartner&&sum!=0){
                    MinNumOfPartner = sum;
                    MinIndexOfPartner = i;
                }
            }


            matchResult.push_back(UnitOfMatching(al.get(MinIndexOfPartner)->getAnimalID(),
                                                 al.get(MinIndexOfPartner)->getAnimalName(),
                                                 cl.get(MinIndexOfClient)->getClientID(),
                                                 cl.get(MinIndexOfClient)->getClientName()));


            cout<<MinIndexOfPartner<<endl;
        cout<<al.get(MinIndexOfPartner)->getAnimalName()<<endl;
            // update the Matrix
            for(int i = 0;i<Matrix.size();i++){
                Matrix[i][MinIndexOfClient] = 0;
            }
            for(int j = 0 ;j <Matrix[0].size();j++){
                Matrix[MinIndexOfPartner][j] = 0;
            }
        }

    }
}

void Matching::initialize(List<Animal>& animallist,List<Client>& clientlist){
    Matrix.clear();
    al = animallist;
    cl = clientlist;
    Matrix.resize(animallist.getLength());
    int y=0;
    for(int i =0; i< Matrix.size(); i++){
       Matrix[i].resize(clientlist.getLength());
    }
    for(int i = 0; i<animallist.getLength();i++){
        for(int j = 0 ;j<clientlist.getLength();j++){
            if(compute(animallist.get(i),clientlist.get(j))>3){
                Matrix[i][j] = 1;
            }else{
                Matrix[i][j] = 0;
            }
        }
    }
}


float Matching::compute(Animal *animal, Client *client){

    int p = 1;
    float r = 0;
    float e = 0;
    float d = 0;


    //prime
    if(client->mi.getHasChild() && client->mi.getHasElder()){
        if(animal->npa.getAggresivity() == 0 || animal->npa.getAggresivity() == 1){
            p *=0;
        }
    }else if((client->mi.getHasChild() && !client->mi.getHasElder())||(!client->mi.getHasChild() && client->mi.getHasElder())){
        if(animal->npa.getAggresivity() == 0){
            p *= 0;
        }else if(animal->npa.getAggresivity() == 1) {
            p *=0.5;
        }
    }else{
        p *=1;
    }

    if(!client->mi.getWillingness()){
        if(animal->npa.getPsychologyDisorder()<=2){
            p *=0;
        }
        if(animal->npa.getResource() == 2){
            p *=0;
        }
    }else{
        p *=1;
    }


    //prefernece
    // personality

    float times = 0;
    int sum = 0;
    for(int i = 0;i<5;i++){
        if(client->mi.getPersonality()[i] != 0){
            sum++;
            if(client->mi.getPersonality()[i] == animal->npa.getPersonality()[i]){
                times += 1.0;
            }
        }
    }
    r +=times/(float)sum;
    // age stage
    r +=1-abs(client->mi.getAge()-animal->pa.getAgeStage())*0.5;

    //serviceability
    if(client->mi.getRequirement() == animal->npa.getServiceability()){
        r += 1000;
    }else{
        r += 0;
    }
    cout<<animal->getAnimalID()<<","<<client->getClientID()<<endl;
    // equation
    // diet
    sum =0;
    for(int i =0 ;i <5;i++){
        sum +=animal->npa.getDiet()[i];
    }

    int salary = client->mi.getIncome();

    e += 1-(sum/(float)salary);
        cout<<animal->getAnimalID()<<","<<client->getClientID()<<endl;
    //time of shelter
    int days = animal->npa.getTimeOfShelter();
    if(days<15){
        e += 0;
    }else{
        e += 1<=log((days-15)/5+1)? 1:log((days-15)/5+1);
    }

    //investment
    int n = 3<=floor(salary/2000)? 3:floor(salary/2000);
    e += 1-abs(animal->npa.getInvestment()-n)/3;

    // distribution
    // Sociality
    if(animal->npa.getSociality()==0){
        if(client->mi.getAvailableTime() == 0){
            d += 1/(float)3;
        }else if(client->mi.getAvailableTime() == 1){
            d += 2/(float)3;
        }else{
            d += 3/(float)3;
        }
    }else if(animal->npa.getSociality()==1){
        if(client->mi.getAvailableTime() == 0){
            d += 3/(float)3;
        }else if(client->mi.getAvailableTime() == 1){
            d += 2/(float)3;
        }else{
            d += 1/(float)3;
        }
    }else if(animal->npa.getSociality()==2){
        if(client->mi.getAvailableTime() == 0){
            d += 2/(float)3;
        }else if(client->mi.getAvailableTime() == 1){
            d += 3/(float)3;
        }else{
            d += 2/(float)3;
        }
    }

    // Adaptability
    if(animal->npa.getAdaptability()==0){
        if(client->mi.getAvailableTime() == 0){
            d += 3/(float)3;
        }else if(client->mi.getAvailableTime() == 1){
            d += 1/(float)3;
        }else{
            d +=1/(float)3;
        }
    }else if(animal->npa.getAdaptability()==1){
        if(client->mi.getAvailableTime() == 0){
            d += 1/(float)3;
        }else if(client->mi.getAvailableTime() == 1){
            d += 3/(float)3;
        }else{
            d += 2/(float)3;
        }
    }else if(animal->npa.getAdaptability()==2){
        if(client->mi.getAvailableTime() == 0){
            d += 1/(float)3;
        }else if(client->mi.getAvailableTime() == 1){
            d += 2/(float)3;
        }else{
            d +=3/(float)3;
        }
    }

cout<<p*(r+e+d)<<endl;
    return p*(r+e+d);

}
